({
	doInit : function(component, event, helper) {
        debugger;
		var action = component.get('c.getAccounts');
        action.setCallback(this, function(a){
            if(a.getState() == "SUCCESS"){
                component.set("v.accList", a.getReturnValue());
            }
        });
        $A.enqueueAction(action);
	}
})